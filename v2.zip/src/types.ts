// TODO: pametniji naziv Interface for the Beer object based on the API response structure.
export type BeerAPI = {
  id: string
  name: string
  image: string
  price: string
  rating: {
    average: number
    reviews: number
  }
}

// TODO: BeerAPI je deo Beer!! Interface for the Beer object based on the APP ????
export type Beer = BeerAPI & {
  // id: string
  // name: string
  // image: string
  // price: string
  // rating: {
  //   average: number
  //   reviews: number
  // }
  feedback: {
    id: string
    comment: string
  }
}

export type UseBeerCollectionData = {
  beerCollection: Beer[]
  isFetching: boolean
  error: string | null
}

export type Feedback = {
  [beerId: string]: string[]
}

export type SnackbarState = {
  open: boolean
  message: string
  severity: 'success' | 'error'
}

export type FilterCriteria = {
  type?: string
  rating: string
}

export type SortCriteria = 'price' | 'rating' | 'name'

export type State = {
  beerCollection: Beer[]
  feedback: Feedback
  isFetching: boolean
  error: string | null
}

export type Action =
  | { type: 'SET_BEER_COLLECTION'; payload: Beer[] }
  | { type: 'ADD_BEER_TO_COLLECTION'; payload: Beer }
  | { type: 'SET_FEEDBACK'; payload: { beerId: string; feedback: string } }
  | { type: 'SET_IS_FETCHING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
