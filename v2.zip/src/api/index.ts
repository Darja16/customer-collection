import { Beer } from '@/types'

const API_BASE_URL = process.env.REACT_APP_TEXT as string

if (!API_BASE_URL) {
  throw new Error('API_BASE_URL is not defined')
}

/**
 * Fetches a beer collection from the API.
 */
export const fetchBeerCollection = async (): Promise<Beer[]> => {
  try {
    const res = await fetch(`${API_BASE_URL}/beers/ale`)

    if (!res.ok) {
      throw new Error(`HTTP error! Status: ${res.status}`)
    }

    const json: Beer[] = await res.json()
    return json
  } catch (error) {
    console.error('Error fetching beer collection:', error)
    throw error
  }
}

/**
 * Fetches a beer by ID from the API.
 *
 * NOTE: This function is not currently being used because the application
 * utilizes a context store to manage the beer collection. This allows
 * for real-time updates and ensures that newly added beers are immediately
 * available on the detail page without requiring an API call.
 *
 * Using the context store avoids the issue of new beers not being part
 * of the API data, providing a consistent user experience.
 */
export const fetchBeerById = async (id: string): Promise<Beer> => {
  try {
    const res = await fetch(`${API_BASE_URL}/beers/ale/${id}`)

    if (!res.ok) {
      throw new Error(`HTTP error! Status: ${res.status}`)
    }

    const json: Beer = await res.json()
    return json
  } catch (error) {
    console.error(`Error fetching beer with ID ${id}:`, error)
    throw error
  }
}
