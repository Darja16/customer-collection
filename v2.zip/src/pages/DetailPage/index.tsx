export * from './DetailPage';
