import React from 'react'
import styles from './ErrorMessage.module.css'
import errorImg from '../../assets/error.gif'

type ErrorMessageProps = {
  error: string
}

// TODO: pozovi ovo gde treba
export function ErrorMessage({ error }: ErrorMessageProps): React.ReactElement {
  return (
    <div className={styles.container}>
      <img src={errorImg} alt="Oops.. something went wrong!" />
      <h1 className={styles.title}>Oops.. Something went wrong!</h1>
      <p className={styles.errorText}>{error}</p>
    </div>
  )
}
