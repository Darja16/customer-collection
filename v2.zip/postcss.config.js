module.exports = {
  plugins: {
    autoprefixer: {},
    'postcss-import': {},
    'tailwindcss/nesting': {},
    tailwindcss: {},
  },
}
